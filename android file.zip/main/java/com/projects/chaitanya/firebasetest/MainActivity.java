package com.projects.chaitanya.firebasetest;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import org.w3c.dom.Text;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button buttonChoose;
    private Button buttonUpload;
    Button send,cam;
    String pic_name;
    TextView result;

    private ImageView imageView;

    private EditText editTextName;

    private Bitmap bitmap;

    private int PICK_IMAGE_REQUEST = 1;

    Uri imageUri;
    ProgressDialog pd;
    private Uri file=null;

    private static final int CAMERA_REQUEST = 1888;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonChoose = (Button)findViewById(R.id.buttonChoose);
        buttonUpload = (Button)findViewById(R.id.buttonUpload);
        send=(Button) findViewById(R.id.button2);
        result=(TextView) findViewById(R.id.textView);
        cam=(Button) findViewById(R.id.button3);

        editTextName = (EditText) findViewById(R.id.editText);

        imageView  = (ImageView) findViewById(R.id.imageView);

        buttonChoose.setOnClickListener(this);
        buttonUpload.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        if(view == buttonChoose){
            showFileChooser();
        }else if(view == buttonUpload){

            pd=new ProgressDialog(this);
            pd.setCancelable(false);
            pd.show();
            uploadImage();
        }
    }

    public void pic(View view)
    {
        Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        pic_name=editTextName.getText().toString();
        File pic =(new File(Environment.getExternalStorageDirectory(),pic_name+ ".jpg"));
        imageUri=Uri.fromFile(pic);
        cameraIntent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, imageUri);

        startActivityForResult(cameraIntent, CAMERA_REQUEST);
    }

    public void getNum(View view)
    {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
     //   String value = dataSnapshot.getValue(String.class);
     //   Log.d("message", "Value is: " + value);
       // result.setText("Total Number of squares in picture is "+value);
       myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                List<String> num = new ArrayList<String>();
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    num.add(postSnapshot.getValue().toString());
                   // String value = dataSnapshot.getValue(String.class);
                   // Log.d("square", "Value is: " + value);
                   // result.setText("Total Number of squares in picture is " + value);
                }
                result.setText("Total Number of squares in picture is " + num.get(0));
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("square", "Failed to read value.", error.toException());
            }
        });
    }

    private void uploadImage() {
        if(file!=null)
        {
            FirebaseStorage storage=FirebaseStorage.getInstance();
            StorageReference reference=storage.getReferenceFromUrl("your bucket name");
            StorageReference imagesRef=reference.child("images/"+editTextName.getText().toString());
            UploadTask uploadTask = imagesRef.putFile(file);
            uploadTask.addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    pd.dismiss();
                    Toast.makeText(MainActivity.this, "Error : "+e.toString(), Toast.LENGTH_SHORT).show();
                }
            }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    pd.dismiss();
                    Toast.makeText(MainActivity.this, "Uploading Done!!!", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void showFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            file = data.getData();

            try {
                //Getting the Bitmap from Gallery
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), file);
                //Setting the Bitmap to ImageView
                //imageView.setImageBitmap(bitmap);
                imageView.setImageURI(file);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {

            file = data.getData();
            Bundle extras = data.getExtras();

            Log.e("URI",imageUri.toString());

            Bitmap bmp = (Bitmap) extras.get("data");

         //   Bitmap photo = (Bitmap) data.getExtras().get("data");
            imageView.setImageURI(imageUri);

           file = data.getData();
        }
    }
}
