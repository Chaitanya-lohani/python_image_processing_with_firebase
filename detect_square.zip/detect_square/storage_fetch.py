import base64
import requests
def get_as_base64(url):
    return base64.b64encode(requests.get(url).content)

url="https://firebasestorage.googleapis.com/v0/b/sd14cs030.appspot.com/o/images%2Ftestpic?alt=media&token=0445cf80-3f2c-4bb2-acc3-b85938c3fbfb"
fh=open("image_fetch1.jpg","wb")
fh.write(base64.b64decode(get_as_base64(url)))
fh.close
